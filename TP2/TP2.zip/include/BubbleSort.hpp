#ifndef BUBBLESORT_HPP
#define BUBBLESORT_HPP

#include <Vertice.hpp>

void BubbleSort(Vertice *vertices, int tamanho);

#endif