#ifndef BUBBLESORT_HPP
#define BUBBLESORT_HPP

#include <stdexcept>

#include <Vertice.hpp>

using namespace std;

void BubbleSort(Vertice *vertices, int tamanho);

#endif