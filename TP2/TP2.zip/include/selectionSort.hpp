#ifndef SELECTIONSORT_HPP
#define SELECTIONSORT_HPP

#include <iostream>
#include <sstream>
#include <string>

#include <vertice.hpp>

using namespace std;

void SelectionSort(Vertice *vertices, int tamanho);

#endif