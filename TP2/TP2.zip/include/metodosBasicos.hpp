// #ifndef METODOS_BASICOS_HPP
// #define METODOS_BASICOS_HPP

// #include <iostream>
// #include <sstream>
// #include <string>

// #include <iostream>
// #include <sstream>
// #include <string>

// #include <vertice.hpp>

// using namespace std;

// void BubbleSort(Vertice *vertices, int tamanho);
// void SelectionSort(Vertice *vertices, int tamanho);
// void InserctionSort(Vertice *vertices, int tamanho);

// #endif