#ifndef PAIRSORT_HPP
#define PAIRSORT_HPP

#include <Vertice.hpp>

void PairSort(Vertice *vertices, int tamanho);

#endif