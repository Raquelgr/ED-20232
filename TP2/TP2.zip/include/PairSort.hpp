#ifndef PAIRSORT_HPP
#define PAIRSORT_HPP

#include <stdexcept>

#include <Vertice.hpp>

using namespace std;

void PairSort(Vertice *vertices, int tamanho);

#endif