#ifndef SELECTIONSORT_HPP
#define SELECTIONSORT_HPP

#include <Vertice.hpp>

void SelectionSort(Vertice *vertices, int tamanho);

#endif