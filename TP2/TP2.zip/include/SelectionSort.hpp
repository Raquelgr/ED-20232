#ifndef SELECTIONSORT_HPP
#define SELECTIONSORT_HPP

#include <stdexcept>

#include <Vertice.hpp>

using namespace std;

void SelectionSort(Vertice *vertices, int tamanho);

#endif