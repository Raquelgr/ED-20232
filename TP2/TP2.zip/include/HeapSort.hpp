#ifndef HEAPSORT_HPP
#define HEAPSORT_HPP

#include <Vertice.hpp>

void HeapSort(Vertice *vertices, int tamanho); 

#endif