#ifndef HEAPSORT_HPP
#define HEAPSORT_HPP

#include <stdexcept>

#include <Vertice.hpp>

using namespace std;

void HeapSort(Vertice *vertices, int tamanho); 

#endif