#ifndef BUBBLESORT_HPP
#define BUBBLESORT_HPP

#include <iostream>
#include <sstream>
#include <string>

#include <vertice.hpp>

using namespace std;

void BubbleSort(Vertice *vertices, int tamanho);

#endif