#ifndef MERGESORT_HPP
#define MERGESORT_HPP

#include <iostream>
#include <sstream>
#include <string>

#include <vertice.hpp>

using namespace std;

void MergeSort(Vertice *vertices, int tamanho); 

#endif