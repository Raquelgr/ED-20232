#ifndef HEAPSORT_HPP
#define HEAPSORT_HPP

#include <iostream>
#include <sstream>
#include <string>

#include <vertice.hpp>

using namespace std;

void HeapSort(Vertice *vertices, int tamanho); 

#endif