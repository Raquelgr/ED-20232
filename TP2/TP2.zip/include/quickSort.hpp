#ifndef QUICKSORT_HPP
#define QUICKSORT_HPP

#include <iostream>
#include <sstream>
#include <string>

#include <vertice.hpp>

using namespace std;

void QuickSort(Vertice *vertices, int tamanho); 

#endif