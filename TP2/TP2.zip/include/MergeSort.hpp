#ifndef MERGESORT_HPP
#define MERGESORT_HPP

#include <Vertice.hpp>

void MergeSort(Vertice *vertices, int tamanho); 

#endif