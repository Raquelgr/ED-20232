#ifndef MERGESORT_HPP
#define MERGESORT_HPP

#include <stdexcept>

#include <Vertice.hpp>

using namespace std;

void MergeSort(Vertice *vertices, int tamanho); 

#endif