#ifndef INSERTIONSORT_HPP
#define INSERTIONSORT_HPP

#include <Vertice.hpp>

void InsertionSort(Vertice *vertices, int tamanho);

#endif