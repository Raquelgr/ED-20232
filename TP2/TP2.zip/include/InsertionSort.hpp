#ifndef INSERTIONSORT_HPP
#define INSERTIONSORT_HPP

#include <stdexcept>

#include <Vertice.hpp>

using namespace std;

void InsertionSort(Vertice *vertices, int tamanho);

#endif