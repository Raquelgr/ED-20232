#ifndef QUICKSORT_HPP
#define QUICKSORT_HPP

#include <Vertice.hpp>

void QuickSort(Vertice *vertices, int tamanho); 

#endif