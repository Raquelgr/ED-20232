#ifndef QUICKSORT_HPP
#define QUICKSORT_HPP

#include <stdexcept>

#include <Vertice.hpp>

using namespace std;

void QuickSort(Vertice *vertices, int tamanho); 

#endif