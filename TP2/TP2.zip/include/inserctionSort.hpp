#ifndef INSERCTIONSORT_HPP
#define INSERCTIONSORT_HPP

#include <iostream>
#include <sstream>
#include <string>

#include <vertice.hpp>

using namespace std;

void InserctionSort(Vertice *vertices, int tamanho);

#endif