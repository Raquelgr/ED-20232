#ifndef SATISFABILIDADE_HPP
#define SATISFABILIDADE_HPP

#include <iostream>
#include <sstream>
#include <string>

using namespace std;

class Satisfabilidade  {
    public:
        string CriaArvore(string formula, string valoracao);
};

#endif